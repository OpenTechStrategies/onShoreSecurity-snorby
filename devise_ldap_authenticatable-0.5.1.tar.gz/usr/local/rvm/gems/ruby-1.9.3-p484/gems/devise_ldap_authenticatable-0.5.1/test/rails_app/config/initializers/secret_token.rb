# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
Rails.application.config.secret_token = '91f200017212d5529ed7dea1959a9bb36b937bdbddab9180114119a36dd9283c7f8c8d22cd299ce6c6f40e6b8121972953658ef357991b4716b7749a9b215402'
