module DeviseLdapAuthenticatable

  class LdapException < Exception
  end

end
