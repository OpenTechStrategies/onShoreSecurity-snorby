require 'test_helper'

class PostTest < ActiveSupport::TestCase
end
