# Include hook code here
require 'devise_ldap_authenticatable'