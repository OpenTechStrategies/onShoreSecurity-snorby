module DeviseLdapAuthenticatable
  VERSION = "0.5.1".freeze
end